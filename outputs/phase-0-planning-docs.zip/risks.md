# Risks

## 1. 技術風險

| 風險 | 影響 | 緩解 |
| --- | --- | --- |
| AI schema 驗證失敗率高 | 使用者無法取得批改 | 使用 Structured Outputs、fixture 測試、一次修正重試、fallback 訊息 |
| 離線同步重複提交 | 進度與掌握度錯誤 | attempt idempotency key、unique constraint、同步狀態機 |
| RLS 設計錯誤 | 使用者資料外洩 | migration 測試、權限單元測試、最小權限政策 |
| React Native 音訊權限差異 | Android/iOS 錄音體驗不一致 | Phase 7 前建立權限矩陣，優先驗證 Android |
| 資料模型過大導致 Phase 1 遲滯 | MVP 進度變慢 | Phase 1 只落地核心 schema 與 scaffold，內容表可分批 migration |

## 2. AI 與成本風險

| 風險 | 影響 | 緩解 |
| --- | --- | --- |
| AI 成本不可控 | 運營成本過高 | rate limit、cache、daily quota、idempotency、成本 dashboard |
| AI 批改過度自信 | 使用者被錯誤教學 | AI 可能出錯提示、C1/C2 抽審、requiresHumanReview |
| Prompt injection | 系統指令被干擾 | 隔離 user content、最小上下文、後端驗證 |
| AI 生成內容品質不穩 | 課程品質下降 | AI 草稿不得直接發布、審核流程、答案一致性檢查 |

## 3. 內容風險

| 風險 | 影響 | 緩解 |
| --- | --- | --- |
| CEFR 程度不準 | 學習者挫折或過度簡單 | 每題標記 level/skills、審核者檢查、錯誤率監控 |
| 中文解釋不符合台灣使用習慣 | 使用者理解成本高 | 建立繁體中文語氣規範與範例 |
| 未授權教材混入 | 法律風險 | 示範內容自行撰寫、保存 source/license |
| C2 內容審核難度高 | 品質不穩 | MVP 僅示範課，C2 內容強制人工審核 |

## 4. 產品風險

| 風險 | 影響 | 緩解 |
| --- | --- | --- |
| 功能範圍過大 | MVP 無法完成 | 嚴守 Phase，第一輪只做文件，MVP 不做社交/付款/排行榜 |
| 使用者期待即時對話 | MVP 口說範圍落差 | 明確標示即時語音對話為後期功能 |
| 學習分析過度複雜 | 使用者看不懂 | 首頁只顯示弱項、到期複習、今日任務與本週趨勢 |

## 5. 測試風險

| 風險 | 影響 | 緩解 |
| --- | --- | --- |
| AI 測試依賴真實 API | CI 不穩且成本增加 | 使用 fixtures 與 mocked responses |
| E2E 太晚建立 | 導覽與登入問題晚期才發現 | Phase 2 後建立 smoke E2E |
| 無障礙只在最後補 | UI 返工 | 元件測試與 checklist 早期納入 |

